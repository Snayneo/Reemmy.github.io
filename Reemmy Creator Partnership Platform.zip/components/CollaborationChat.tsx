import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Avatar, Avatar, AvatarFallback } from "./ui/avatar";
import { ScrollArea } from "./ui/scroll-area";
import { 
  Send, 
  Search, 
  Users, 
  Video, 
  Calendar,
  Paperclip,
  Smile
} from "lucide-react";

export function CollaborationChat() {
  const [selectedChat, setSelectedChat] = useState(0);
  const [message, setMessage] = useState("");

  const chats = [
    {
      id: 1,
      creator: "@foodblogger_mila",
      avatar: "M",
      topic: "Рецепт пасты",
      lastMessage: "Отлично! Когда снимаем?",
      time: "10:30",
      unread: 2,
      online: true
    },
    {
      id: 2,
      creator: "@tech_reviews",
      avatar: "T",
      topic: "Обзор гаджетов",
      lastMessage: "Отправил список продуктов",
      time: "9:15",
      unread: 0,
      online: false
    },
    {
      id: 3,
      creator: "@lifestyle_anna",
      avatar: "A",
      topic: "Утренняя рутина",
      lastMessage: "Согласна на коллаб!",
      time: "Вчера",
      unread: 1,
      online: true
    }
  ];

  const messages = [
    {
      id: 1,
      sender: "@foodblogger_mila",
      content: "Привет! Видела твой контент, очень классный! Хочешь сделать коллаб?",
      time: "10:00",
      isOwn: false
    },
    {
      id: 2,
      sender: "Ты",
      content: "Привет! Да, было бы круто! Что у тебя в планах?",
      time: "10:05",
      isOwn: true
    },
    {
      id: 3,
      sender: "@foodblogger_mila",
      content: "Думала снять совместный рецепт пасты с элементами Reemmy. У тебя кулинарный контент тоже есть?",
      time: "10:08",
      isOwn: false
    },
    {
      id: 4,
      sender: "Ты",
      content: "Да, иногда готовлю! Это будет отличное видео. Когда планируешь снимать?",
      time: "10:12",
      isOwn: true
    },
    {
      id: 5,
      sender: "@foodblogger_mila",
      content: "Отлично! Когда снимаем?",
      time: "10:30",
      isOwn: false
    }
  ];

  const handleSendMessage = () => {
    if (message.trim()) {
      // Здесь будет логика отправки сообщения
      setMessage("");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl mb-2">Чаты и коллаборации</h1>
          <p className="text-muted-foreground">Общайся с другими создателями и планируй совместный контент</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
          {/* Chat List */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Чаты</CardTitle>
                <Button size="sm" variant="outline">
                  <Users className="h-4 w-4 mr-2" />
                  Найти
                </Button>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Поиск чатов..." className="pl-10" />
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[500px]">
                {chats.map((chat, index) => (
                  <div
                    key={chat.id}
                    className={`p-4 border-b cursor-pointer hover:bg-gray-50 transition-colors ${
                      selectedChat === index ? 'bg-blue-50 border-l-4 border-l-blue-500' : ''
                    }`}
                    onClick={() => setSelectedChat(index)}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <Avatar>
                          <AvatarFallback className="bg-gradient-to-r from-purple-400 to-blue-400 text-white">
                            {chat.avatar}
                          </AvatarFallback>
                        </Avatar>
                        {chat.online && (
                          <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="truncate">{chat.creator}</h4>
                          <span className="text-xs text-muted-foreground">{chat.time}</span>
                        </div>
                        <p className="text-sm text-muted-foreground truncate">{chat.lastMessage}</p>
                        <Badge variant="secondary" className="text-xs mt-1">
                          {chat.topic}
                        </Badge>
                      </div>
                      {chat.unread > 0 && (
                        <div className="bg-blue-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                          {chat.unread}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Chat Window */}
          <Card className="lg:col-span-2">
            <CardHeader className="border-b">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarFallback className="bg-gradient-to-r from-purple-400 to-blue-400 text-white">
                      {chats[selectedChat]?.avatar}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3>{chats[selectedChat]?.creator}</h3>
                    <p className="text-sm text-muted-foreground">
                      {chats[selectedChat]?.online ? 'В сети' : 'Был в сети недавно'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button size="sm" variant="outline">
                    <Video className="h-4 w-4 mr-2" />
                    Видеозвонок
                  </Button>
                  <Button size="sm" variant="outline">
                    <Calendar className="h-4 w-4 mr-2" />
                    Планировать
                  </Button>
                </div>
              </div>
            </CardHeader>

            <CardContent className="p-0 flex flex-col h-[500px]">
              {/* Messages */}
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.isOwn ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[70%] ${msg.isOwn ? 'order-1' : 'order-2'}`}>
                        <div
                          className={`rounded-lg px-4 py-2 ${
                            msg.isOwn
                              ? 'bg-blue-500 text-white'
                              : 'bg-gray-100 text-gray-900'
                          }`}
                        >
                          <p>{msg.content}</p>
                        </div>
                        <p className={`text-xs text-muted-foreground mt-1 ${
                          msg.isOwn ? 'text-right' : 'text-left'
                        }`}>
                          {msg.time}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>

              {/* Message Input */}
              <div className="p-4 border-t">
                <div className="flex items-center space-x-2">
                  <Button size="sm" variant="ghost">
                    <Paperclip className="h-4 w-4" />
                  </Button>
                  <Input
                    placeholder="Написать сообщение..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    className="flex-1"
                  />
                  <Button size="sm" variant="ghost">
                    <Smile className="h-4 w-4" />
                  </Button>
                  <Button size="sm" onClick={handleSendMessage}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="p-4">
            <div className="flex items-center space-x-3">
              <div className="bg-purple-100 text-purple-600 p-2 rounded-lg">
                <Users className="h-5 w-5" />
              </div>
              <div>
                <h4>Найти создателей</h4>
                <p className="text-sm text-muted-foreground">По интересам и аудитории</p>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-100 text-blue-600 p-2 rounded-lg">
                <Video className="h-5 w-5" />
              </div>
              <div>
                <h4>Шаблоны коллабов</h4>
                <p className="text-sm text-muted-foreground">Готовые идеи для контента</p>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center space-x-3">
              <div className="bg-green-100 text-green-600 p-2 rounded-lg">
                <Calendar className="h-5 w-5" />
              </div>
              <div>
                <h4>Планировщик</h4>
                <p className="text-sm text-muted-foreground">Синхронизация съемок</p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}