import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  DollarSign, 
  TrendingUp, 
  Users, 
  Video, 
  Eye, 
  Heart, 
  MessageCircle,
  Share2,
  Plus
} from "lucide-react";

export function CreatorDashboard() {
  const earnings = [
    { video: "Утренняя рутина с Reemmy", views: 3200, likes: 480, earnings: 850 },
    { video: "Коллаб с @username", views: 5600, likes: 720, earnings: 1200 },
    { video: "Обзор продукта + Reemmy", views: 2800, likes: 340, earnings: 650 },
    { video: "Челлендж от Reemmy", views: 4100, likes: 580, earnings: 950 }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl">Панель создателя</h1>
            <p className="text-muted-foreground">Добро пожаловать обратно, @username!</p>
          </div>
          <Button className="bg-gradient-to-r from-purple-600 to-blue-600">
            <Plus className="h-4 w-4 mr-2" />
            Создать контент
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm">Общий заработок</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl">₽3,650</div>
              <p className="text-xs text-muted-foreground">
                +20.1% за последний месяц
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm">Активные видео</CardTitle>
              <Video className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl">12</div>
              <p className="text-xs text-muted-foreground">
                +4 за эту неделю
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm">Подписчики</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl">1,247</div>
              <p className="text-xs text-muted-foreground">
                +15% рост
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm">Вовлечённость</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl">4.2%</div>
              <p className="text-xs text-muted-foreground">
                +0.8% улучшение
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="earnings" className="space-y-6">
          <TabsList>
            <TabsTrigger value="earnings">Заработок</TabsTrigger>
            <TabsTrigger value="content">Контент</TabsTrigger>
            <TabsTrigger value="collaborations">Коллабы</TabsTrigger>
            <TabsTrigger value="tools">Инструменты</TabsTrigger>
          </TabsList>

          <TabsContent value="earnings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Заработок по видео</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {earnings.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <h4 className="mb-1">{item.video}</h4>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <div className="flex items-center space-x-1">
                            <Eye className="h-4 w-4" />
                            <span>{item.views.toLocaleString()}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Heart className="h-4 w-4" />
                            <span>{item.likes}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg">₽{item.earnings}</div>
                        <Badge variant="secondary">Выплачено</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="content" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Активный контент</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {earnings.map((item, index) => (
                    <Card key={index} className="border">
                      <CardContent className="p-4">
                        <div className="aspect-video bg-gradient-to-br from-purple-100 to-blue-100 rounded-lg mb-3 flex items-center justify-center">
                          <Video className="h-8 w-8 text-muted-foreground" />
                        </div>
                        <h4 className="mb-2">{item.video}</h4>
                        <div className="flex justify-between text-sm text-muted-foreground">
                          <span>{item.views.toLocaleString()} просмотров</span>
                          <span>₽{item.earnings}</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="collaborations" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Доступные коллаборации</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { creator: "@foodblogger", followers: "5.2K", topic: "Рецепты", match: 85 },
                    { creator: "@techreview", followers: "3.8K", topic: "Технологии", match: 72 },
                    { creator: "@lifestyle_anna", followers: "2.1K", topic: "Лайфстайл", match: 94 }
                  ].map((collab, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-blue-400 rounded-full flex items-center justify-center text-white">
                          {collab.creator[1].toUpperCase()}
                        </div>
                        <div>
                          <h4>{collab.creator}</h4>
                          <p className="text-sm text-muted-foreground">
                            {collab.followers} подписчиков • {collab.topic}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="text-right">
                          <div className="text-sm">Совместимость</div>
                          <Progress value={collab.match} className="w-20" />
                        </div>
                        <Button size="sm">Связаться</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tools" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Элементы Reemmy</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button variant="outline" className="w-full justify-start">
                    🎨 Скачать логотипы
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    🎵 Аудио элементы
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    ✨ Стикеры и фильтры
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    📝 Готовые фразы
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Аналитика</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span>Охват за неделю</span>
                    <span>15,700</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Средний CPM</span>
                    <span>₽45</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Конверсия в подписки</span>
                    <span>2.3%</span>
                  </div>
                  <Button className="w-full">
                    Подробная аналитика
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}