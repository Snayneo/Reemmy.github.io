import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { TrendingUp, Users, DollarSign, MessageCircle, Video, Target } from "lucide-react";

interface LandingPageProps {
  onGetStarted?: () => void;
  onLogin?: () => void;
}

export function LandingPage({ onGetStarted, onLogin }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-2 rounded-lg">
                <TrendingUp className="h-6 w-6" />
              </div>
              <h1 className="text-2xl">Reemmy</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" onClick={onLogin}>Войти</Button>
              <Button onClick={onGetStarted}>Присоединиться</Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex justify-center mb-6">
            <Badge variant="secondary" className="text-lg px-4 py-2">
              🚀 Новая эра партнёрок
            </Badge>
          </div>
          <h1 className="text-5xl mb-6 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Reemmy — партнёрка, где зарабатывают ВСЕ
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Даже если у тебя 1K подписчиков — ты уже можешь зарабатывать. 
            Это новый формат партнёрки в TikTok и других соцсетях.
          </p>
          <div className="flex justify-center space-x-4">
            <Button size="lg" className="bg-gradient-to-r from-purple-600 to-blue-600" onClick={onGetStarted}>
              Начать зарабатывать
            </Button>
            <Button size="lg" variant="outline">
              Узнать больше
            </Button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg bg-white/70 backdrop-blur">
              <CardHeader>
                <MessageCircle className="h-12 w-12 text-purple-600 mb-4" />
                <CardTitle>💬 Чаты и коллабы</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Общайся с другими авторами, находи партнёров для совместного контента
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-white/70 backdrop-blur">
              <CardHeader>
                <Users className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>🤝 Участие в подсети</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Стань частью платформы, где каждый ролик может приносить доход
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-white/70 backdrop-blur">
              <CardHeader>
                <Video className="h-12 w-12 text-green-600 mb-4" />
                <CardTitle>🎥 Элементы Reemmy</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Добавляй логотип, фразы, стикеры, звуки в свои ролики
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-white/70 backdrop-blur">
              <CardHeader>
                <DollarSign className="h-12 w-12 text-yellow-600 mb-4" />
                <CardTitle>💸 Деньги за каждый ролик</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Получай оплату даже с 1-2 тысячами подписчиков
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-white/70 backdrop-blur">
              <CardHeader>
                <TrendingUp className="h-12 w-12 text-red-600 mb-4" />
                <CardTitle>📈 Рост вместе с аудиторией</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Зарабатывай больше по мере роста просмотров и активности
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-white/70 backdrop-blur">
              <CardHeader>
                <Target className="h-12 w-12 text-indigo-600 mb-4" />
                <CardTitle>🔗 Часть экосистемы</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Каждый автор усиливает охват и помогает расти всей платформе
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Example Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl text-center mb-12">Пример работы</h2>
          <Card className="border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="bg-purple-100 text-purple-600 rounded-full p-2">
                    <Users className="h-5 w-5" />
                  </div>
                  <p>У тебя 1200 подписчиков</p>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="bg-blue-100 text-blue-600 rounded-full p-2">
                    <Video className="h-5 w-5" />
                  </div>
                  <p>Ты снимаешь короткое видео с упоминанием Reemmy</p>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="bg-green-100 text-green-600 rounded-full p-2">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <p>Видео собирает 3K просмотров и 500 лайков</p>
                </div>
                <div className="flex items-center space-x-3 bg-yellow-50 rounded-lg p-4">
                  <div className="bg-yellow-100 text-yellow-600 rounded-full p-2">
                    <DollarSign className="h-5 w-5" />
                  </div>
                  <p>💸 Ты получаешь оплату от системы за активность и вовлечённость!</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl text-center mb-12">Что даёт Reemmy</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {[
              "✔️ Простая регистрация",
              "✔️ Минимум требований", 
              "✔️ Поддержка даже самых маленьких блогеров",
              "✔️ Удобный чат для коллабораций",
              "✔️ Постоянный рост дохода",
              "✔️ Бонусы за приглашения"
            ].map((benefit, index) => (
              <div key={index} className="flex items-center space-x-3 p-4 bg-white/70 rounded-lg">
                <div className="text-green-600">
                  ✔️
                </div>
                <p>{benefit.replace("✔️ ", "")}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h2 className="text-4xl mb-6">Готов начать зарабатывать?</h2>
          <p className="text-xl mb-8 opacity-90">
            Присоединяйся к Reemmy уже сегодня и начни получать доход с каждого ролика
          </p>
          <Button size="lg" variant="secondary" className="bg-white text-purple-600 hover:bg-gray-100" onClick={onGetStarted}>
            Присоединиться к Reemmy
          </Button>
        </div>
      </section>
    </div>
  );
}